from flask import Flask, request, jsonify
import os
from flask_cors import CORS
from dotenv import load_dotenv
from openai import OpenAI
from langchain_community.embeddings import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from brain import generate_quiz_questions, get_index_for_pdf

app = Flask(__name__)
CORS(app)

# Load environment variables from .env file
load_dotenv()

# Set up the OpenAI client using the API key from the environment variable
api_key = os.getenv('OPENAI_API_KEY')
client = OpenAI(api_key=api_key)

# Global variable to store the vectordb
vectordb = None

def create_vectordb(files, filenames):
    global vectordb
    vectordb = get_index_for_pdf(files, filenames, api_key)



@app.route('/quiz', methods=['GET'])
def get_quiz():
    print(f"Received request with params: {request.args}")
    sem = request.args.get('sem', '')
    dept = request.args.get('dept', '')
    level = request.args.get('level', '')
    subject = request.args.get('subject', '')
    unit = request.args.get('unit', '')
    
    print(sem)
    print(dept)
    print(level)
    
    
    
        # Assume PDF files are stored locally
    pdf_directory = f"D:/rag/pdfs/{dept}Sem-{sem}/{subject}/{unit}"  # Update this path
    pdf_files = [os.path.join(pdf_directory, f) for f in os.listdir(pdf_directory) if f.endswith('.pdf')]
    pdf_file_names = [os.path.basename(f) for f in pdf_files]

# Create vectordb on app startup
    with app.app_context():
        create_vectordb([open(f, 'rb').read() for f in pdf_files], pdf_file_names)
  
    if not sem:
        return jsonify({"error": "No question provided"}), 400
    
    if not dept:
      return jsonify({"error": "No question provided"}), 400
    
    if not level:
        return jsonify({"error": "No question provided"}), 400

    if not vectordb:
        return jsonify({"error": "Vector database not initialized"}), 500
    

    
   

    # Search the vectordb for similar content to the user's question
    search_results = vectordb.similarity_search("What is the meaning of life?", k=3)
    pdf_extract = "\n".join([result.page_content for result in search_results])
    
    

    # Generate quiz questions
    result = generate_quiz_questions(client=client, model="gpt-4o-2024-08-06", pdf_extract=pdf_extract)

    return jsonify(result)

if __name__ == '__main__':
 
    app.run(debug=True)
